<form action="" method="POST">
    <input type="text" name="email" value="" id="email" class="form-control text-dark" placeholder="Your email here" /><br/>
    <input type="submit" name="submit" onclick="submit_me()" value="Subscribe" class="btn border-outline border-white text-secondary" />
</form>