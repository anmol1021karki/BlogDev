

<!-- Remove the container if you want to extend the Footer to full width. -->
<section class="bg-dark">
<div class="container bg-dark my-">

    <footer class="text-center text-lg-start">
    <!-- Grid container -->
    <div class="container p-4">
      <!--Grid row-->
      <div class="row">
        <!--Grid column-->
        <div class="col-sm">
          <h5 class="text-uppercase mb-4 text-primary">OUR WORLD</h5>

          <ul class="list-unstyled mb-4">
            <li>
              <a href="index.php" class="text-light">Home</a>
            </li>
            <li>
              <a href="#!" class="text-light">About us</a>
            </li>
            <li>
              <a href="#!" class="text-light">Collections</a>
            </li>
            
          </ul>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-sm text-white">
          <h5 class="text-uppercase mb-4 text-primary">Contact Us</h5>
            <div class="contact-col text-light">
               <div>
               <h7>
                <i class="fas fa-home"></i>
                <span>
                  Ramshah Path, Anmol Complex
                  <p>Putalisadak, Kathmandu, NP</p>
                </span></h7>
              </div>
              <div>
              <h7><i class="fas fa-phone"></i>
                <span>
                  +1 2073794
                  <p>Everyday, 11AM to 6PM</p>
                </span></h7>
              </div>
              <div>
              <h7>
                <i class="fas fa-envelope"></i>
                <span>
                  meroblog@info.com
                </span></h7>
              </div>
            </div>
        </div>

        <!--Grid column-->

        <!--Grid column-->
        <div class="col-sm">
          <h5 class="text-uppercase mb-4 text-primary">Sign up to our newsletter</h5>
          <div>
            <div>
              <div>
                <?php include 'subscribe.php'; ?>
              </div>
            </div>
          </div> 
        </div>
        <!--Grid column-->
      </div>
      <!--Grid row-->
    </div>
    <!-- Grid container -->

    <!-- Copyright -->
    <div class="text-center p-3 border-top border-white text-secondary">
      © 2022 Copyright:
      <a class="text-secondary" href="https://mmeroblog.com/">MeroBlog.com</a>
    </div>
    <!-- Copyright -->
  </footer>
  
</div>
<!-- End of .container -->      
</section>
  <script type="text/javascript" charset="utf-8">

    function submit_me() {
    var email_value = $('#email').val();
    $.post("subscribe.php", { email: email_value }, function(response) {
    if (response!='') {alert(response)};
      alert('Thank You !');
      });
    }
  </script>

<!--Bootstrap JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

  
</body>
</html>
