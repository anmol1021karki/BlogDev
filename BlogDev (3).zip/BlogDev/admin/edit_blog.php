<?php
include "header.php";
//GET BLOG ID
$blogID = $_GET['id'];
if(empty($blogID)){
    header("location: index.php");
}

if(isset($_SESSION['user_data'])){
    $author_id = $_SESSION['user_data']['0'];
}

//Fetch categories
$sql = "SELECT * FROM categories";
$query = mysqli_query($con, $sql);

$sql1 = "SELECT * FROM myblog LEFT JOIN categories ON myblog.category=categories.cat_id 
         LEFT JOIN user ON myblog.author_id=user.u_id WHERE blog_id='$blogID'";
$query1 = mysqli_query($con, $sql1);
$result = mysqli_fetch_assoc($query1);
?>

<div class="container">
    <h5 class="mb-2 text-gray-800">Categories</h5>
    <div class="row">
        <div class="col-xl-8 col-lg-6">
            <div class="card-header">
                <h6 class="font-weight-bold text-primary mt-2">Publish Blog/Article</h6>
            </div>
            <div class="card-body">
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        
                        <input type="text" name="blog_title" placeholder="Category Name" class="form-control" required value="<?= $result['blog_title'] ?>">
                    </div>
                    <div class="mb-3">
                        <label>Body/Description</label>
                        <textarea class="form-control" placeholder="Body" name="blog_body" rows="2" id="blog" required><?= $result['blog_body'] ?></textarea>
                    </div>
                    <div class="mb-3">
                        <input type="file" name="blog_img" class="form-control">
                        <img src="upload/<?=$result['blog_img']?>" width="100px" class="border shadow">
                    </div>
                    <div class="mb-3">
                        <select class="form-control" name="category" required>
                            <?php 
                                while($cats = mysqli_fetch_assoc($query)) {
                            ?>
                            <option value="<?= $cats['cat_id'] ?>"
                                    <?= ($result['category']==$cats['cat_id'])?"selected":''; ?>>
                                    <?= $cats['cat_name'] ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <input type="submit" name="edit_blog" value="Update" class="btn btn-primary">
                        <a href="categories.php" class="btn btn-secondary">Back</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php
include "footer.php";

if(isset($_POST['edit_blog'])){
    $title = mysqli_real_escape_string($con, $_POST['blog_title']);
    $body = mysqli_real_escape_string($con, $_POST['blog_body']);

    $filename = $_FILES['blog_img']['name'];
    $tmp_name = $_FILES['blog_img']['tmp_name'];
    $size = $_FILES['blog_img']['size'];
    $image_ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    $allow_type = ['jpg','png','jpeg','gif'];
    $destination = "upload/".$filename;

    $category = mysqli_real_escape_string($con, $_POST['category']);

    if(!empty($filename)){
        if (in_array($image_ext, $allow_type)){
            if ($size <= 2000000) {
                $unlink = "upload/".$result['blog_img'];
                unlink($unlink);
                move_uploaded_file($tmp_name, $destination);

                $sql2 = "UPDATE myblog SET blog_title='$title',blog_body='$body',blog_img='$filename',category='$category',author_id='$author_id' 
                        WHERE blog_id='$blogID'";
                move_uploaded_file($tmp_name, $destination);
                $query2 = mysqli_query($con, $sql2);
    
                if ($query2){
                    $msg=['Post Updated Successfully','alert-success'];
                    $_SESSION['msg']=$msg;
                    header("location: index.php");
                }
                else{
                    $msg=['Failed to update..Please try again!','alert-danger'];
                    $_SESSION['msg']=$msg;
                    header("location: index.php");
                }
            }
            else{
                $msg=['Image should not be greater than 2mb','alert-danger'];
                $_SESSION['msg']=$msg;
                header("location: index.php");
            }
        }
        else{
            $msg=['Only jpg, png, jpeg and gif are supported','alert-danger'];
            $_SESSION['msg']=$msg;
            header("location: index.php");
        }
    }
    else{
        $sql2 = "UPDATE myblog SET blog_title='$title',blog_body='$body',category='$category',author_id='$author_id' 
                    WHERE blog_id='$blogID'";
        move_uploaded_file($tmp_name, $destination);
        $query2 = mysqli_query($con, $sql2);
    
        if ($query2){
            $msg=['Post Updated Successfully','alert-success'];
            $_SESSION['msg']=$msg;
            header("location: index.php");
        }
        else{
            $msg=['Failed to update..Please try again!','alert-danger'];
            $_SESSION['msg']=$msg;
            header("location: index.php");
        }
    }
}
?>

